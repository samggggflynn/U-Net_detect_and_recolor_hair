# unet

<div>
<img src="./screenshots/14.jpg" height="256">
<img src="./screenshots/h.14.jpg" height="256">
<img src="./screenshots/mask.jpg" height="256">
</div>

训练好的[模型](https://pan.baidu.com/s/1arpxQ2r0hLtHzIN9QXDHKw)

我把设计思路写在维基中了：https://github.com/zhaipro/unet/wiki
