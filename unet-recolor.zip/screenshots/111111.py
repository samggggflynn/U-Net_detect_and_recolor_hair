name = '(1,2,3)'
print(len(name))